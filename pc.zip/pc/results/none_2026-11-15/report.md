# Condition comparison (none amplitude)

7 trials, 1 conditions, sessions: 2026-11-15

| condition | trials | median SNR (dB) |
|---|---|---|
| blank d=15 | 7 | 44 |
