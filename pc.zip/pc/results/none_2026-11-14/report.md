# Condition comparison (none amplitude)

13 trials, 3 conditions, sessions: 2026-11-14

| condition | trials | median SNR (dB) |
|---|---|---|
| blank d=15 | 3 | 51 |
| object vertebra x=0 y=0 d=15 | 5 | 52 |
| offset vertebra x=10 y=0 d=15 | 5 | 46 |

## Repeatability (log amplitude)

Within = spread between repeats of the same condition (reseating). Ratio = between-condition SD / within SD; below 1 means repeats scatter more than the conditions differ.

| disc | median repeat spread | median ratio | best ratio (freq) | median ICC |
|---|---|---|---|---|
| up right | 70% | 1.06 | 2.41 (386 Hz) | 0.49 |
| up left | 16% | 1.26 | 3.88 (372 Hz) | 0.53 |
| down left | 54% | 1.84 | 2.68 (246 Hz) | 0.78 |
| down right | 72% | 0.73 | 3.01 (372 Hz) | 0.21 |

## Pairs of conditions

| pair | features with abs(d) > 2 | features with no overlap | strongest (disc, freq, ratio, d) |
|---|---|---|---|
| object vertebra x=0 y=0 d=15 vs blank d=15 | 15 / 104 | 12 | up left, 316 Hz, x2.59, d=+6.0 |
| offset vertebra x=10 y=0 d=15 vs blank d=15 | 55 / 104 | 62 | up left, 372 Hz, x0.56, d=-6.6 |
| offset vertebra x=10 y=0 d=15 vs object vertebra x=0 y=0 d=15 | 45 / 104 | 39 | down right, 372 Hz, x0.59, d=-4.6 |

Leave-one-out nearest-centroid accuracy over the whole sweep: **92%** (chance 33%, 13 trials). With only a few repeats per condition treat this as a sanity check, not a result.
