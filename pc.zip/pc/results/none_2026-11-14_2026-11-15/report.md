# Condition comparison (none amplitude)

20 trials, 3 conditions, sessions: 2026-11-14, 2026-11-15

| condition | trials | median SNR (dB) |
|---|---|---|
| blank d=15 | 10 | 47 |
| object vertebra x=0 y=0 d=15 | 5 | 52 |
| offset vertebra x=10 y=0 d=15 | 5 | 46 |

## Repeatability (log amplitude)

Within = spread between repeats of the same condition (reseating). Ratio = between-condition SD / within SD; below 1 means repeats scatter more than the conditions differ.

| disc | median repeat spread | median ratio | best ratio (freq) | median ICC |
|---|---|---|---|---|
| up right | 77% | 0.94 | 1.92 (372 Hz) | 0.40 |
| up left | 109% | 0.34 | 0.78 (316 Hz) | -0.04 |
| down left | 100% | 0.94 | 1.55 (344 Hz) | 0.36 |
| down right | 331488% | 0.59 | 0.84 (358 Hz) | 0.20 |

## Pairs of conditions

| pair | features with abs(d) > 2 | features with no overlap | strongest (disc, freq, ratio, d) |
|---|---|---|---|
| object vertebra x=0 y=0 d=15 vs blank d=15 | 3 / 104 | 1 | up right, 330 Hz, x2.08, d=+2.7 |
| offset vertebra x=10 y=0 d=15 vs blank d=15 | 8 / 104 | 1 | up right, 78 Hz, x0.28, d=-2.4 |
| offset vertebra x=10 y=0 d=15 vs object vertebra x=0 y=0 d=15 | 45 / 104 | 39 | down right, 372 Hz, x0.59, d=-4.6 |

Leave-one-out nearest-centroid accuracy over the whole sweep: **70%** (chance 33%, 20 trials). With only a few repeats per condition treat this as a sanity check, not a result.
