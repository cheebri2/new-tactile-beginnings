# Condition comparison (share amplitude)

2 trials, 1 conditions, sessions: 2026-11-14

| condition | trials | median SNR (dB) |
|---|---|---|
| blank d=15 | 2 | 35 |
